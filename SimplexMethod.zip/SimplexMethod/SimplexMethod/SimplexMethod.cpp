// SimplexMethod.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>


#define CHOICE2 2
#define CHOICE3 3
#define CHOICE4 4


using namespace std;


struct PivotCoor
{
	int i;
	int j;
};

struct OptimalValue
{
	int i;
	int j;
};

int Menu()
{
	cout << "Press 1. 2x2 Game" << endl;
	cout << "Press 2. 3x3 Game" << endl;
	cout << "Press 3. 4x4 Game" << endl;
	int ch = 0;
	cin >> ch;
	return ch;
}
int LowestVal(double(*data)[CHOICE2], int length)
{
	int val = 1000000;
	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length; j++)
		{
			if (data[i][j] < val)
			{
				val = data[i][j];
			}
		}
	}
	if (val < 0)
	{
		val = val;
	}
	else
	{
		val = 0;
	}
	return val;
}
void AddValue(double(*data)[CHOICE2], int length, int value)
{
	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length; j++)
		{
			data[i][j] = data[i][j] + abs(value);
		}
	}
}
void AddEdges(double(*data)[CHOICE2], int length, double(*n_data)[CHOICE2 + 1], int n_length)
{
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (i < length && j < length)
			{
				n_data[i][j] = data[i][j];
			}
			else if (i == length && j != length)
			{
				n_data[i][j] = -1;
			}
			else if(j == length && i !=length)
			{
				n_data[i][j] = 1;
			}
			else if (i == length && j == length)
			{
				n_data[i][j] = 0;
			}
		}
	}
}
PivotCoor Pivot(int x, int y, double(*n_data)[CHOICE2 + 1], int n_length)
{
	int tempj = 0, tempi = 0;
	double temp = 11110.0;
	bool temp_j = false;
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (n_data[n_length - 1][j]  < 0 && temp_j == false)
			{
				tempj = j;
				temp_j = true;
			}
		}
	}
	for (int i = 0; i < n_length-1; i++)
	{
		double value = n_data[i][n_length - 1]/ n_data[i][tempj]  ;
		if (value < temp)
		{
			temp = value;
			tempi = i;
		}
	}
	return { tempi,tempj };
}
void Algorithm(double(*n_data)[CHOICE2 + 1], int n_length,int pivoti, int pivotj)
{
	double temparray[CHOICE2 + 1][CHOICE2 + 1];
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (i != pivoti && j != pivotj)
			{
				temparray[i][j] = n_data[i][j] - (n_data[pivoti][j] * n_data[i][pivotj] / n_data[pivoti][pivotj]);
			}
			else if (i == pivoti && j != pivotj)
			{
				temparray[i][j] = n_data[i][j] / n_data[pivoti][pivotj];
			}
			else if (i != pivoti && j == pivotj)
			{
				temparray[i][j] = -n_data[i][j] / n_data[pivoti][pivotj];
			}
			else if (i == pivoti && j == pivotj)
			{
				temparray[i][j] = 1 / n_data[pivoti][pivotj];
			}
		}
	}
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			n_data[i][j] = temparray[i][j];
		}
	}
}
bool CheckforNeg(double(*n_data)[CHOICE2 + 1], int n_length)
{
	for (int j = 0; j < n_length;j++)
	{
		if (n_data[n_length - 1][j] < 0)
		{
			return true;
		}
	}
	return false;
}
double CalculateValue(double value)
{
	return 1.0 / value;
}
void XStrategy(int(*strategy_x), int value)
{
	strategy_x[value] = strategy_x[value] + 1;
}
void YStrategy(int(*strategy_y), int value)
{
	strategy_y[value] = strategy_y[value] + 1;
}
OptimalValue StrategyCalc(double(*n_data)[CHOICE2 + 1],int(*strategy_x), int(*strategy_y), int length, int optimali, int optimalj)
{
	int winx = 0;
	int winy = 0;
	double tempx = 0.0;
	double tempy = 0.0;
	for (int i = 0; i < length; i++)
	{
		if (strategy_x[i] % 2 == 0)
		{
			strategy_x[i] = 0;
		}
		if (strategy_y[i] % 2 == 0)
		{
			strategy_y[i] = 0;
		}
	}

	for (int i = 0; i < length; i++)
	{
		if (strategy_x[i] != 0)
		{
			double prob = n_data[length + 1][i] / n_data[length + 1][length + 1];
			if (prob > tempx)
			{
				tempx = prob;
				winx = i;
			}
		}
	}

	for (int i = 0; i < length; i++)
	{
		if (strategy_y[i] != 0)
		{
			double prob = n_data[i][length + 1] / n_data[length + 1][length + 1];
			if (prob > tempy)
			{
				tempy = prob;
				winy = i;
			}
		}
	}
	
	return { winx,winy };
}


int LowestVal3(double(*data)[CHOICE3], int length)
{
	int val = 1000000;
	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length; j++)
		{
			if (data[i][j] < val)
			{
				val = data[i][j];
			}
		}
	}
	if (val < 0)
	{
		val = val;
	}
	else
	{
		val = 0;
	}
	return val;
}
void AddValue3(double(*data)[CHOICE3], int length, int value)
{
	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length; j++)
		{
			data[i][j] = data[i][j] + abs(value);
		}
	}
}
void AddEdges3(double(*data)[CHOICE3], int length, double(*n_data)[CHOICE3 + 1], int n_length)
{
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (i < length && j < length)
			{
				n_data[i][j] = data[i][j];
			}
			else if (i == length && j != length)
			{
				n_data[i][j] = -1;
			}
			else if (j == length && i != length)
			{
				n_data[i][j] = 1;
			}
			else if (i == length && j == length)
			{
				n_data[i][j] = 0;
			}
		}
	}
}
void Algorithm3(double(*n_data)[CHOICE3 + 1], int n_length, int pivoti, int pivotj)
{
	double temparray[CHOICE3 + 1][CHOICE3 + 1];
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (i != pivoti && j != pivotj)
			{
				temparray[i][j] = n_data[i][j] - (n_data[pivoti][j] * n_data[i][pivotj] / n_data[pivoti][pivotj]);
			}
			else if (i == pivoti && j != pivotj)
			{
				temparray[i][j] = n_data[i][j] / n_data[pivoti][pivotj];
			}
			else if (i != pivoti && j == pivotj)
			{
				temparray[i][j] = -n_data[i][j] / n_data[pivoti][pivotj];
			}
			else if (i == pivoti && j == pivotj)
			{
				temparray[i][j] = 1 / n_data[pivoti][pivotj];
			}
		}
	}
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			n_data[i][j] = temparray[i][j];
		}
	}
}
bool CheckforNeg3(double(*n_data)[CHOICE3 + 1], int n_length)
{
	for (int j = 0; j < n_length;j++)
	{
		if (n_data[n_length - 1][j] < 0)
		{
			return true;
		}
	}
	return false;
}
OptimalValue StrategyCalc3(double(*n_data)[CHOICE3 + 1], int(*strategy_x), int(*strategy_y), int length, int optimali, int optimalj)
{
	int winx = 0;
	int winy = 0;
	double tempx = 0.0;
	double tempy = 0.0;
	for (int i = 0; i < length; i++)
	{
		if (strategy_x[i] % 2 == 0)
		{
			strategy_x[i] = 0;
		}
		if (strategy_y[i] % 2 == 0)
		{
			strategy_y[i] = 0;
		}
	}

	for (int i = 0; i < length; i++)
	{
		if (strategy_x[i] != 0)
		{
			double prob = n_data[length + 1][i] / n_data[length + 1][length + 1];
			if (prob > tempx)
			{
				tempx = prob;
				winx = i;
			}
		}
	}

	for (int i = 0; i < length; i++)
	{
		if (strategy_y[i] != 0)
		{
			double prob = n_data[i][length + 1] / n_data[length + 1][length + 1];
			if (prob > tempy)
			{
				tempy = prob;
				winy = i;
			}
		}
	}

	return { winx,winy };
}
PivotCoor Pivot3(int x, int y, double(*n_data)[CHOICE3 + 1], int n_length)
{
	int tempj = 0, tempi = 0;
	double temp = 11110.0;
	bool temp_j = false;
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (n_data[n_length - 1][j] < 0 && temp_j == false)
			{
				tempj = j;
				temp_j = true;
			}
		}
	}
	for (int i = 0; i < n_length - 1; i++)
	{
		double value = n_data[i][n_length - 1] / n_data[i][tempj];
		if (value < temp)
		{
			temp = value;
			tempi = i;
		}
	}
	return { tempi,tempj };
}


int LowestVal4(double(*data)[CHOICE4], int length)
{
	int val = 1000000;
	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length; j++)
		{
			if (data[i][j] < val)
			{
				val = data[i][j];
			}
		}
	}
	if (val < 0)
	{
		val = val;
	}
	else
	{
		val = 0;
	}
	return val;
}
void AddValue4(double(*data)[CHOICE4], int length, int value)
{
	for (int i = 0; i < length; i++)
	{
		for (int j = 0; j < length; j++)
		{
			data[i][j] = data[i][j] + abs(value);
		}
	}
}
void AddEdges4(double(*data)[CHOICE4], int length, double(*n_data)[CHOICE4 + 1], int n_length)
{
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (i < length && j < length)
			{
				n_data[i][j] = data[i][j];
			}
			else if (i == length && j != length)
			{
				n_data[i][j] = -1;
			}
			else if (j == length && i != length)
			{
				n_data[i][j] = 1;
			}
			else if (i == length && j == length)
			{
				n_data[i][j] = 0;
			}
		}
	}
}
void Algorithm4(double(*n_data)[CHOICE4 + 1], int n_length, int pivoti, int pivotj)
{
	double temparray[CHOICE4 + 1][CHOICE4 + 1];
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (i != pivoti && j != pivotj)
			{
				temparray[i][j] = n_data[i][j] - (n_data[pivoti][j] * n_data[i][pivotj] / n_data[pivoti][pivotj]);
			}
			else if (i == pivoti && j != pivotj)
			{
				temparray[i][j] = n_data[i][j] / n_data[pivoti][pivotj];
			}
			else if (i != pivoti && j == pivotj)
			{
				temparray[i][j] = -n_data[i][j] / n_data[pivoti][pivotj];
			}
			else if (i == pivoti && j == pivotj)
			{
				temparray[i][j] = 1 / n_data[pivoti][pivotj];
			}
		}
	}
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			n_data[i][j] = temparray[i][j];
		}
	}
}
bool CheckforNeg4(double(*n_data)[CHOICE4 + 1], int n_length)
{
	for (int j = 0; j < n_length;j++)
	{
		if (n_data[n_length - 1][j] < 0)
		{
			return true;
		}
	}
	return false;
}
OptimalValue StrategyCalc4(double(*n_data)[CHOICE4 + 1], int(*strategy_x), int(*strategy_y), int length, int optimali, int optimalj)
{
	int winx = 0;
	int winy = 0;
	double tempx = 0.0;
	double tempy = 0.0;
	for (int i = 0; i < length; i++)
	{
		if (strategy_x[i] % 2 == 0)
		{
			strategy_x[i] = 0;
		}
		if (strategy_y[i] % 2 == 0)
		{
			strategy_y[i] = 0;
		}
	}

	for (int i = 0; i < length; i++)
	{
		if (strategy_x[i] != 0)
		{
			double prob = n_data[length + 1][i] / n_data[length + 1][length + 1];
			if (prob > tempx)
			{
				tempx = prob;
				winx = i;
			}
		}
	}

	for (int i = 0; i < length; i++)
	{
		if (strategy_y[i] != 0)
		{
			double prob = n_data[i][length + 1] / n_data[length + 1][length + 1];
			if (prob > tempy)
			{
				tempy = prob;
				winy = i;
			}
		}
	}

	return { winx,winy };
}
PivotCoor Pivot4(int x, int y, double(*n_data)[CHOICE4 + 1], int n_length)
{
	int tempj = 0, tempi = 0;
	double temp = 11110.0;
	bool temp_j = false;
	for (int i = 0; i < n_length; i++)
	{
		for (int j = 0; j < n_length; j++)
		{
			if (n_data[n_length - 1][j] < 0 && temp_j == false)
			{
				tempj = j;
				temp_j = true;
			}
		}
	}
	for (int i = 0; i < n_length - 1; i++)
	{
		double value = n_data[i][n_length - 1] / n_data[i][tempj];
		if (value < temp)
		{
			temp = value;
			tempi = i;
		}
	}
	return { tempi,tempj };
}



void Simplex4(double(*data)[CHOICE4], int length)
{
	int strategy_x[CHOICE4] = { 0 };
	int strategy_y[CHOICE4] = { 0 };

	int optimali = 0;
	int optimalj = 0;

	bool neg_check = true;
	int pivoti = 0, pivotj = 0;
	int low_val = LowestVal4(data, length);
	AddValue4(data, length, low_val);
	double n_data[CHOICE4 + 1][CHOICE4 + 1];
	int n_length = length + 1;
	AddEdges4(data, length, n_data, n_length);

	do
	{
		auto returnval = Pivot4(pivoti, pivotj, n_data, n_length);

		pivoti = returnval.i;
		pivotj = returnval.j;

		Algorithm4(n_data, n_length, pivoti, pivotj);

		neg_check = CheckforNeg4(n_data, n_length);

		XStrategy(strategy_x, pivoti);
		YStrategy(strategy_y, pivotj);
	} while (neg_check == true);


	auto returnopt = StrategyCalc4(n_data, strategy_x, strategy_y, length, optimali, optimalj);

	double value = CalculateValue(n_data[n_length - 1][n_length - 1]);
	cout << "Value of the Game is " << value + low_val << endl;

	cout << "Optimal Strategy for Player1 (Row Player) is strategy " << returnopt.j << endl;
	cout << "Optimal Strategy for Player2 (Column Player) is strategy " << returnopt.i << endl;
}
void Simplex3(double(*data)[CHOICE3], int length)
{
	int strategy_x[CHOICE3] = { 0 };
	int strategy_y[CHOICE3] = { 0 };

	int optimali = 0;
	int optimalj = 0;

	bool neg_check = true;
	int pivoti = 0, pivotj = 0;
	int low_val = LowestVal3(data, length);
	AddValue3(data, length, low_val);
	double n_data[CHOICE3 + 1][CHOICE3 + 1];
	int n_length = length + 1;
	AddEdges3(data, length, n_data, n_length);

	do
	{
		auto returnval = Pivot3(pivoti, pivotj, n_data, n_length);

		pivoti = returnval.i;
		pivotj = returnval.j;

		Algorithm3(n_data, n_length, pivoti, pivotj);
		
		neg_check = CheckforNeg3(n_data, n_length);

		XStrategy(strategy_x, pivoti);
		YStrategy(strategy_y, pivotj);
	} while (neg_check == true);


	auto returnopt = StrategyCalc3(n_data, strategy_x, strategy_y, length, optimali, optimalj);

	double value = CalculateValue(n_data[n_length - 1][n_length - 1]);
	cout << "Value of the Game is " << value + low_val << endl;

	cout << "Optimal Strategy for Player1 (Row Player) is strategy " << returnopt.j << endl;
	cout << "Optimal Strategy for Player2 (Column Player) is strategy " << returnopt.i << endl;
}
void Simplex2(double(*data)[CHOICE2], int length)
{
	int strategy_x[CHOICE2] = { 0 };
	int strategy_y[CHOICE2] = { 0 };

	int optimali = 0;
	int optimalj = 0;

	bool neg_check = true;
	int pivoti=0, pivotj=0;
	int low_val = LowestVal(data,length);
	AddValue(data, length,low_val);
	double n_data[CHOICE2 + 1][CHOICE2 + 1];
	int n_length = length + 1;
	AddEdges(data, length, n_data, n_length);
	do
	{
		auto returnval = Pivot(pivoti, pivotj, n_data, n_length);

		pivoti = returnval.i;
		pivotj = returnval.j;
		Algorithm(n_data, n_length, pivoti, pivotj);

		neg_check = CheckforNeg(n_data, n_length);

		XStrategy(strategy_x, pivoti);
		YStrategy(strategy_y, pivotj);

	} while (neg_check == true);


	auto returnopt = StrategyCalc(n_data,strategy_x, strategy_y,length, optimali,optimalj);

	double value = CalculateValue(n_data[n_length - 1][n_length - 1]);
	cout << "Value of the Game is " << value + low_val << endl;

	cout << "Optimal Strategy for Player1 (Row Player) is strategy " << returnopt.j << endl;
	cout << "Optimal Strategy for Player2 (Column Player) is strategy " << returnopt.i << endl;
	//for (int i = 0; i < n_length; i++)
	//{
	//	for (int j = 0; j < n_length; j++)
	//	{
	//		cout << n_data[i][j] << " ";
	//	}
	//	cout << endl;
	//}
	//cout << "pivot : " << pivoti << " , " << pivotj << endl;



}

int main()
{
	int choice = Menu();
	int length = 0;
	char yes_no = '\n';
	if (choice == 1)
	{
		
		double data[CHOICE2][CHOICE2];
		length = 2;
		do
		{
			cout << "Enter values in the matrix one by one" << endl;
			for (int i = 0; i < length; i++)
			{
				for (int j = 0; j < length; j++)
				{
					cin >> data[i][j];
				}
			}

			cout << "Entered matrix is " << endl;
			for (int i = 0; i < length; i++)
			{
				for (int j = 0; j < length; j++)
				{
					cout << data[i][j] << " ";
				}
				cout << endl;
			}

			cout << "Is this the correct matrix? Please enter Y or N)" << endl;
			cin >> yes_no;
		} while (yes_no == 'n' || yes_no == 'N');
		

		Simplex2(data, length);
	}
	else if (choice == 2)
	{
		double data[CHOICE3][CHOICE3];
		length = 3;
		do
		{
			cout << "Enter values in the matrix one by one" << endl;
			for (int i = 0; i < length; i++)
			{
				for (int j = 0; j < length; j++)
				{
					cin >> data[i][j];
				}
			}

			cout << "Entered matrix is " << endl;
			for (int i = 0; i < length; i++)
			{
				for (int j = 0; j < length; j++)
				{
					cout << data[i][j] << " ";
				}
				cout << endl;
			}

			cout << "Is this the correct matrix? Please enter Y or N)" << endl;
			cin >> yes_no;
		} while (yes_no == 'n' || yes_no == 'N');

		Simplex3(data, length);
	}
	else if (choice == 3)
	{
		double data[CHOICE4][CHOICE4];
		length = 4;
		do
		{
			cout << "Enter values in the matrix one by one" << endl;
			for (int i = 0; i < length; i++)
			{
				for (int j = 0; j < length; j++)
				{
					cin >> data[i][j];
				}
			}

			cout << "Entered matrix is " << endl;
			for (int i = 0; i < length; i++)
			{
				for (int j = 0; j < length; j++)
				{
					cout << data[i][j] << " ";
				}
				cout << endl;
			}

			cout << "Is this the correct matrix? Please enter Y or N)" << endl;
			cin >> yes_no;
		} while (yes_no == 'n' || yes_no == 'N');

		Simplex4(data, length);
	}

}

